<?php
/*
Plugin Name: Random Quote
Description: Een simpele plugin die een willekeurige quote toont bij elke paginalaad.
Version: 1.1
Author: Bryce van der Werf
*/

/**
 * Geeft een willekeurige quote terug uit de array.
 *
 * @return string $random_quote De willekeurige quote.
 */
function get_random_quotes()
{
    $quotes = [
        "Het leven is wat je ervan maakt.",
        "Elke dag is een nieuwe kans.",
        "Succes komt van doorzetten.",
        "Blijf geloven in jezelf.",
        "De enige manier om iets te doen, is door het te doen.",
        "Geloof in de kracht van nu.",
        "Falen is het bewijs dat je het probeert.",
        "Volg je dromen, ze kennen de weg.",
        "Maak van elke dag een meesterwerk.",
        "Wees de verandering die je wilt zien in de wereld.",
        "Doe elke dag iets waar je bang voor bent.",
        "Alles wat je nodig hebt, is al in je.",
        "Grote dingen worden niet gedaan door impulsen, maar door een reeks kleine dingen.",
        "De beste tijd om een boom te planten was 20 jaar geleden. De op één na beste tijd is nu.",
        "Kracht komt niet van wat je kunt doen, maar van het overwinnen van de dingen die je dacht dat je niet kon.",
        "Het enige wat je hoeft te doen om te falen, is opgeven.",
        "Je kunt niet veranderen wat je niet onder ogen ziet.",
        "Doe wat je kunt, met wat je hebt, waar je bent.",
        "Laat je niet afleiden door wat anderen denken.",
        "Het pad naar succes is altijd in aanbouw.",
        "Dromen worden niet waargemaakt zonder hard werken.",
        "Niet alles wat telt kan worden geteld, en niet alles wat geteld kan worden, telt.",
        "Wees niet bang om te falen. Wees bang om het nooit te proberen.",
        "Je kunt je toekomst niet voorspellen, maar je kunt hem wel creëren.",
        "Wat je ook doet, doe het goed of doe het niet.",
        "De enige beperking die je hebt, is degene die je jezelf oplegt.",
        "Volg je hart, maar neem je brein mee.",
        "Succes is het resultaat van voorbereiding, hard werken en leren van mislukking.",
        "Het is niet de sterkste van de soorten die overleeft, noch de meest intelligente, maar degene die het meest reageert op verandering.",
        "Het belangrijkste is niet wat je kijkt, maar wat je ziet.",
        "Het geluk komt vaak voort uit de dingen die je niet verwacht.",
        "Je hebt alles in je om grootse dingen te bereiken.",
        "Succes is geen eindbestemming, het is een reis.",
        "Het enige wat tussen jou en je doel in staat, is de bereidheid om te proberen.",
        "Iedereen heeft een plan totdat ze een klap in het gezicht krijgen.",
        "Als je niet probeert, weet je nooit of het mogelijk is.",
        "Je grootste kracht ligt in je vastberadenheid.",
        "Het maakt niet uit hoe langzaam je gaat, zolang je niet stopt.",
        "Je moet het eerst geloven voordat je het kunt bereiken.",
        "Als je niet bereid bent om alles te verliezen, kun je niet verwachten te winnen.",
        "De beste manier om de toekomst te voorspellen, is door hem te creëren.",
        "Als je stopt met proberen, geef je op.",
        "Wees niet bang voor het onbekende, het kan een kans zijn.",
        "Als je niet kunt doen wat je wilt, doe dan wat je kunt.",
        "Het gaat niet om het hebben van tijd, maar om het maken van tijd.",
        "Wat je ook in het leven doet, zorg dat je het doet met passie.",
        "Het maakt niet uit hoeveel je hebt, zolang je maar gelukkig bent.",
        "De beste manier om te beginnen is met stoppen met praten en beginnen met doen.",
        "Als je niet de moed hebt om het te proberen, zul je nooit weten wat je kunt bereiken.",
        "Alles wat je doet, laat een impact achter.",
        "Als je probeert te falen, heb je al gewonnen.",
        "De eerste stap naar succes is het nemen van de stap zelf.",
        "Vandaag is de eerste dag van de rest van je leven.",
        "Laat je dromen groter zijn dan je angsten.",
        "De enige manier om geweldig werk te doen, is door van wat je doet te houden.",
        "Mislukking is de sleutel tot succes; elke fout leert je iets.",
        "Wees de beste versie van jezelf.",
        "Tijd is kostbaar, maak er het meeste van.",
        "Laat nooit iemand je vertellen dat je iets niet kunt doen.",
        "De moeilijkste dingen zijn vaak de mooiste.",
        "Je kunt niet wachten op inspiratie, je moet er zelf voor zorgen.",
        "Alles is mogelijk als je er in gelooft.",
        "Laat je niet beperken door wat anderen denken.",
        "Blijf altijd proberen, zelfs als het moeilijk is.",
        "Geloof in je eigen kracht.",
        "Het leven is 10% wat er met je gebeurt en 90% hoe je ermee omgaat.",
        "Durf te falen, want dat is de enige manier om te slagen.",
        "Kijk niet naar de klok, doe gewoon wat de klok doet: blijf doorgaan.",
        "Als je iets wilt bereiken, stop dan niet met proberen.",
        "Wees niet bang om groot te dromen.",
        "Het enige dat tussen jou en je droom staat, is de bereidheid om het te proberen.",
        "Er is geen geheim voor succes, het is hard werken en leren van je fouten.",
        "Mensen die zeggen dat het niet kan, moeten niet iemand stoppen die het aan het doen is.",
        "Je grootste concurrent is jezelf.",
        "Stop met denken, begin met doen.",
        "Kleine stappen leiden tot grote resultaten.",
        "Alles gebeurt om een reden, dus maak het beste van alles.",
        "Jij bent de architect van je eigen toekomst.",
        "De toekomst behoort aan degenen die geloven in de schoonheid van hun dromen.",
        "Zonder risico geen beloning.",
        "Wees de beste versie van jezelf, elke dag.",
        "Niemand kan jou tegenhouden, behalve jijzelf.",
        "Het is nooit te laat om opnieuw te beginnen.",
        "De enige grens die je hebt, is de grens die je jezelf stelt.",
        "Als je iets kunt dromen, kun je het ook doen.",
        "Het enige dat je hoeft te doen, is volhouden.",
        "Geef nooit op, grote dingen nemen tijd.",
        "Als je het niet probeert, weet je nooit of je het kunt.",
        "De kracht van verbeelding is sterker dan kennis.",
        "Jij hebt de controle over je toekomst.",
        "Je hebt alles in je om succes te behalen.",
        "Maak van elke dag een nieuwe kans.",
        "De eerste stap naar succes is het begin.",
        "Soms moet je risico's nemen om vooruit te komen.",
        "Het enige dat tussen jou en je droom staat, is de angst om het te proberen.",
        "Maak gebruik van elke gelegenheid die je krijgt.",
        "Geloof in jezelf en alles wordt mogelijk.",
        "Laat je angsten je niet stoppen.",
        "De kracht van vandaag is de beloning van morgen.",
        "Succes komt met geduld en doorzettingsvermogen.",
        "Je toekomst is wat je ervan maakt.",
        "De mooiste dingen in het leven zijn vaak de eenvoudigste.",
        "Geef nooit op, want de beste dingen komen onverwacht.",
        "Wat je vandaag doet, bepaalt je toekomst.",
        "Maak je dromen waar.",
        "Blijf positief, zelfs in moeilijke tijden.",
        "Elke stap telt, hoe klein ook.",
        "Laat het verleden los en kijk vooruit.",
        "Met elke fout kom je dichter bij succes."
    ];

    $random_quote = $quotes[array_rand($quotes)];
    return $random_quote;
}

/**
 * Toont een willekeurige quote op de pagina.
 *
 * De quotes worden opgehaald uit de array in get_random_quotes.
 *
 * @return string $random_quote De willekeurige quote, omringd door een div met een CSS class 'random-quote'.
 */
function display_random_quote()
{
    $quote = get_random_quotes();
    return "<div class='random-quote' style='font-size: 18px; color: #333; font-family: Arial, sans-serif; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px;'>\"$quote\"</div>";
}

add_shortcode('random_quote', 'display_random_quote');
